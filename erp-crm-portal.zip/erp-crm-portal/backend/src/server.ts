import './types/express-augment';
import app from './app';
import { env } from './config/env';
import { logger } from './config/logger';
import { prisma } from './config/prisma';

async function main() {
  await prisma.$connect();
  logger.info('Connected to PostgreSQL database');

  const server = app.listen(env.port, () => {
    logger.info(`Server running in ${env.nodeEnv} mode on port ${env.port}`);
    logger.info(`API base URL: http://localhost:${env.port}/api/v1`);
  });

  server.on('error', (err: NodeJS.ErrnoException) => {
    if (err.code === 'EADDRINUSE') {
      logger.error(
        `Port ${env.port} is already in use by another process.\n` +
          `  Fix: find and stop whatever is using it, e.g.\n` +
          `    Windows (PowerShell):  netstat -ano | findstr :${env.port}   then   taskkill /PID <pid> /F\n` +
          `    macOS/Linux:           lsof -i :${env.port}                  then   kill -9 <pid>\n` +
          `  Or change PORT in backend/.env (and VITE_API_BASE_URL in frontend/.env) to a free port instead.`
      );
      process.exit(1);
    } else {
      logger.error('Server failed to start:', err);
      process.exit(1);
    }
  });

  const shutdown = async (signal: string) => {
    logger.info(`${signal} received. Shutting down gracefully...`);
    server.close(async () => {
      await prisma.$disconnect();
      process.exit(0);
    });
  };

  process.on('SIGINT', () => shutdown('SIGINT'));
  process.on('SIGTERM', () => shutdown('SIGTERM'));
}

main().catch((err) => {
  logger.error('Failed to start server:', err);
  process.exit(1);
});
