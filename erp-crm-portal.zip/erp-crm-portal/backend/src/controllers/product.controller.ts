import { Request, Response } from 'express';
import { MovementType } from '@prisma/client';
import { asyncHandler } from '../utils/asyncHandler';
import * as productService from '../services/product.service';
import { getPagination } from '../utils/pagination';

export const listProducts = asyncHandler(async (req: Request, res: Response) => {
  const pagination = getPagination(req);
  const search = req.query.search as string | undefined;
  const category = req.query.category as string | undefined;
  const lowStockOnly = req.query.lowStockOnly === 'true';
  const result = await productService.listProducts(pagination, search, category, lowStockOnly);
  res.status(200).json({ success: true, ...result });
});

export const getProduct = asyncHandler(async (req: Request, res: Response) => {
  const product = await productService.getProductById(req.params.id);
  res.status(200).json({ success: true, data: product });
});

export const createProduct = asyncHandler(async (req: Request, res: Response) => {
  const product = await productService.createProduct(req.body);
  res.status(201).json({ success: true, data: product });
});

export const updateProduct = asyncHandler(async (req: Request, res: Response) => {
  const product = await productService.updateProduct(req.params.id, req.body);
  res.status(200).json({ success: true, data: product });
});

export const recordStockMovement = asyncHandler(async (req: Request, res: Response) => {
  const { quantity, movementType, reason } = req.body;
  const result = await productService.recordStockMovement(
    req.params.id,
    req.user!.userId,
    quantity,
    movementType as MovementType,
    reason
  );
  res.status(201).json({ success: true, data: result });
});

export const listStockMovements = asyncHandler(async (req: Request, res: Response) => {
  const pagination = getPagination(req);
  const productId = req.query.productId as string | undefined;
  const movementType = req.query.movementType as MovementType | undefined;
  const result = await productService.listStockMovements(pagination, productId, movementType);
  res.status(200).json({ success: true, ...result });
});
