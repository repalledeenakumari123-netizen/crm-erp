import { Request, Response } from 'express';
import { CustomerStatus, CustomerType } from '@prisma/client';
import { asyncHandler } from '../utils/asyncHandler';
import * as customerService from '../services/customer.service';
import { getPagination } from '../utils/pagination';

export const listCustomers = asyncHandler(async (req: Request, res: Response) => {
  const pagination = getPagination(req);
  const search = req.query.search as string | undefined;
  const status = req.query.status as CustomerStatus | undefined;
  const customerType = req.query.customerType as CustomerType | undefined;
  const result = await customerService.listCustomers(pagination, search, status, customerType);
  res.status(200).json({ success: true, ...result });
});

export const getCustomer = asyncHandler(async (req: Request, res: Response) => {
  const customer = await customerService.getCustomerById(req.params.id);
  res.status(200).json({ success: true, data: customer });
});

export const createCustomer = asyncHandler(async (req: Request, res: Response) => {
  const customer = await customerService.createCustomer(req.body);
  res.status(201).json({ success: true, data: customer });
});

export const updateCustomer = asyncHandler(async (req: Request, res: Response) => {
  const customer = await customerService.updateCustomer(req.params.id, req.body);
  res.status(200).json({ success: true, data: customer });
});

export const addFollowUp = asyncHandler(async (req: Request, res: Response) => {
  const { note, followUpDate } = req.body;
  const followUp = await customerService.addFollowUp(req.params.id, req.user!.userId, note, followUpDate);
  res.status(201).json({ success: true, data: followUp });
});
