import { Request, Response } from 'express';
import { asyncHandler } from '../utils/asyncHandler';
import * as authService from '../services/auth.service';
import { ApiError } from '../utils/ApiError';

export const login = asyncHandler(async (req: Request, res: Response) => {
  const { email, password } = req.body;
  const result = await authService.login(email, password);
  res.status(200).json({ success: true, data: result });
});

export const refreshToken = asyncHandler(async (req: Request, res: Response) => {
  const { refreshToken: token } = req.body;
  if (!token) throw ApiError.badRequest('Refresh token is required');
  const result = await authService.refresh(token);
  res.status(200).json({ success: true, data: result });
});

export const logout = asyncHandler(async (_req: Request, res: Response) => {
  res.status(200).json({ success: true, message: 'Logged out successfully' });
});

export const me = asyncHandler(async (req: Request, res: Response) => {
  const profile = await authService.getProfile(req.user!.userId);
  res.status(200).json({ success: true, data: profile });
});

export const changePassword = asyncHandler(async (req: Request, res: Response) => {
  const { currentPassword, newPassword } = req.body;
  const result = await authService.changePassword(req.user!.userId, currentPassword, newPassword);
  res.status(200).json({ success: true, ...result });
});

export const createUser = asyncHandler(async (req: Request, res: Response) => {
  const user = await authService.createUser(req.body);
  res.status(201).json({ success: true, data: user });
});

export const listUsers = asyncHandler(async (_req: Request, res: Response) => {
  const users = await authService.listUsers();
  res.status(200).json({ success: true, data: users });
});
