import { Request, Response } from 'express';
import { ChallanStatus } from '@prisma/client';
import { asyncHandler } from '../utils/asyncHandler';
import * as challanService from '../services/challan.service';
import { getPagination } from '../utils/pagination';

export const listChallans = asyncHandler(async (req: Request, res: Response) => {
  const pagination = getPagination(req);
  const status = req.query.status as ChallanStatus | undefined;
  const customerId = req.query.customerId as string | undefined;
  const search = req.query.search as string | undefined;
  const result = await challanService.listChallans(pagination, status, customerId, search);
  res.status(200).json({ success: true, ...result });
});

export const getChallan = asyncHandler(async (req: Request, res: Response) => {
  const challan = await challanService.getChallanById(req.params.id);
  res.status(200).json({ success: true, data: challan });
});

export const createChallan = asyncHandler(async (req: Request, res: Response) => {
  const { customerId, items, status } = req.body;
  const challan = await challanService.createChallan(customerId, items, req.user!.userId, status);
  res.status(201).json({ success: true, data: challan });
});

export const updateChallan = asyncHandler(async (req: Request, res: Response) => {
  const challan = await challanService.updateChallan(req.params.id, req.body);
  res.status(200).json({ success: true, data: challan });
});

export const confirmChallan = asyncHandler(async (req: Request, res: Response) => {
  const challan = await challanService.confirmChallan(req.params.id, req.user!.userId);
  res.status(200).json({ success: true, data: challan });
});

export const cancelChallan = asyncHandler(async (req: Request, res: Response) => {
  const challan = await challanService.cancelChallan(req.params.id, req.user!.userId);
  res.status(200).json({ success: true, data: challan });
});
