import { ChallanStatus, Prisma } from '@prisma/client';
import { prisma } from '../config/prisma';
import { ApiError } from '../utils/ApiError';
import { PaginationParams, buildMeta } from '../utils/pagination';

interface ChallanItemInput {
  productId: string;
  quantity: number;
}

async function generateChallanNumber(tx: Prisma.TransactionClient): Promise<string> {
  const count = await tx.challan.count();
  return `CH-${String(count + 1).padStart(5, '0')}`;
}

/** Merge duplicate productId entries in the same request into a single quantity. */
function mergeItems(items: ChallanItemInput[]): ChallanItemInput[] {
  const map = new Map<string, number>();
  for (const item of items) {
    map.set(item.productId, (map.get(item.productId) || 0) + item.quantity);
  }
  return Array.from(map.entries()).map(([productId, quantity]) => ({ productId, quantity }));
}

async function buildSnapshotItems(tx: Prisma.TransactionClient, items: ChallanItemInput[]) {
  const merged = mergeItems(items);
  const snapshotItems = [];

  for (const item of merged) {
    const product = await tx.product.findUnique({ where: { id: item.productId } });
    if (!product) throw ApiError.badRequest(`Product ${item.productId} not found`);

    snapshotItems.push({
      productId: product.id,
      productNameSnapshot: product.name,
      productSkuSnapshot: product.sku,
      unitPriceSnapshot: product.unitPrice,
      quantity: item.quantity,
      lineTotal: Number(product.unitPrice) * item.quantity,
    });
  }

  return snapshotItems;
}

/**
 * Verifies sufficient stock for every item and decrements it atomically.
 * Throws a 409 Conflict (without partially applying any changes, since this
 * runs inside the caller's transaction) if ANY item has insufficient stock —
 * stock must never go negative.
 */
async function deductStockForItems(
  tx: Prisma.TransactionClient,
  items: { productId: string | null; quantity: number; productNameSnapshot: string; productSkuSnapshot: string }[],
  createdById: string,
  reason: string
) {
  // Check all items first so a failure partway through never leaves stock
  // partially decremented.
  for (const item of items) {
    if (!item.productId) continue; // product was deleted after being added to a draft — cannot fulfill
    const product = await tx.product.findUnique({ where: { id: item.productId } });
    if (!product) {
      throw ApiError.conflict(
        `Product "${item.productNameSnapshot}" (SKU: ${item.productSkuSnapshot}) no longer exists and cannot be fulfilled.`
      );
    }
    if (product.currentStock < item.quantity) {
      throw ApiError.conflict(
        `Insufficient stock for "${product.name}" (SKU: ${product.sku}). Available: ${product.currentStock}, required: ${item.quantity}.`
      );
    }
  }

  for (const item of items) {
    if (!item.productId) continue;
    const product = await tx.product.update({
      where: { id: item.productId },
      data: { currentStock: { decrement: item.quantity } },
    });
    await tx.stockMovement.create({
      data: {
        productId: item.productId,
        quantityChanged: item.quantity,
        movementType: 'OUT',
        reason,
        createdById,
      },
    });
    void product;
  }
}

async function restoreStockForItems(
  tx: Prisma.TransactionClient,
  items: { productId: string | null; quantity: number }[],
  createdById: string,
  reason: string
) {
  for (const item of items) {
    if (!item.productId) continue; // product no longer exists — nothing to restore
    const exists = await tx.product.findUnique({ where: { id: item.productId } });
    if (!exists) continue;
    await tx.product.update({
      where: { id: item.productId },
      data: { currentStock: { increment: item.quantity } },
    });
    await tx.stockMovement.create({
      data: {
        productId: item.productId,
        quantityChanged: item.quantity,
        movementType: 'IN',
        reason,
        createdById,
      },
    });
  }
}

export async function createChallan(
  customerId: string,
  items: ChallanItemInput[],
  createdById: string,
  status: 'DRAFT' | 'CONFIRMED' = 'DRAFT'
) {
  return prisma.$transaction(async (tx) => {
    const customer = await tx.customer.findUnique({ where: { id: customerId } });
    if (!customer) throw ApiError.badRequest('Customer not found');

    const snapshotItems = await buildSnapshotItems(tx, items);
    const totalQuantity = snapshotItems.reduce((sum, i) => sum + i.quantity, 0);
    const challanNumber = await generateChallanNumber(tx);

    const challan = await tx.challan.create({
      data: {
        challanNumber,
        customerId,
        createdById,
        totalQuantity,
        status: 'DRAFT', // always created as DRAFT first; confirmed below if requested
        items: { create: snapshotItems },
      },
      include: { items: true, customer: true },
    });

    if (status === 'CONFIRMED') {
      await deductStockForItems(tx, challan.items, createdById, `Sales Challan ${challan.challanNumber}`);
      return tx.challan.update({
        where: { id: challan.id },
        data: { status: 'CONFIRMED', confirmedAt: new Date() },
        include: { items: true, customer: true },
      });
    }

    return challan;
  });
}

export async function updateChallan(
  id: string,
  input: { customerId?: string; items?: ChallanItemInput[] }
) {
  return prisma.$transaction(async (tx) => {
    const existing = await tx.challan.findUnique({ where: { id }, include: { items: true } });
    if (!existing) throw ApiError.notFound('Challan not found');
    if (existing.status !== 'DRAFT') {
      throw ApiError.conflict(
        `Cannot edit a challan that is already ${existing.status.toLowerCase()}. Only draft challans can be edited.`
      );
    }

    if (input.customerId) {
      const customer = await tx.customer.findUnique({ where: { id: input.customerId } });
      if (!customer) throw ApiError.badRequest('Customer not found');
    }

    if (input.items) {
      await tx.challanItem.deleteMany({ where: { challanId: id } });
      const snapshotItems = await buildSnapshotItems(tx, input.items);
      const totalQuantity = snapshotItems.reduce((sum, i) => sum + i.quantity, 0);
      await tx.challan.update({
        where: { id },
        data: {
          customerId: input.customerId,
          totalQuantity,
          items: { create: snapshotItems },
        },
      });
    } else if (input.customerId) {
      await tx.challan.update({ where: { id }, data: { customerId: input.customerId } });
    }

    return tx.challan.findUnique({ where: { id }, include: { items: true, customer: true } });
  });
}

export async function confirmChallan(id: string, userId: string) {
  return prisma.$transaction(async (tx) => {
    const challan = await tx.challan.findUnique({ where: { id }, include: { items: true } });
    if (!challan) throw ApiError.notFound('Challan not found');
    if (challan.status !== 'DRAFT') {
      throw ApiError.conflict(`Challan is already ${challan.status.toLowerCase()} and cannot be confirmed again.`);
    }
    if (challan.items.length === 0) {
      throw ApiError.badRequest('Cannot confirm a challan with no line items.');
    }

    await deductStockForItems(tx, challan.items, userId, `Sales Challan ${challan.challanNumber}`);

    return tx.challan.update({
      where: { id },
      data: { status: 'CONFIRMED', confirmedAt: new Date() },
      include: { items: true, customer: true },
    });
  });
}

/**
 * Cancelling a DRAFT challan simply marks it cancelled (stock was never
 * touched). Cancelling a CONFIRMED challan restores the stock it had
 * deducted, logging IN movements — this reversal behavior is a documented
 * assumption (see README "Assumptions").
 */
export async function cancelChallan(id: string, userId: string) {
  return prisma.$transaction(async (tx) => {
    const challan = await tx.challan.findUnique({ where: { id }, include: { items: true } });
    if (!challan) throw ApiError.notFound('Challan not found');
    if (challan.status === 'CANCELLED') {
      throw ApiError.conflict('Challan is already cancelled.');
    }

    if (challan.status === 'CONFIRMED') {
      await restoreStockForItems(tx, challan.items, userId, `Challan ${challan.challanNumber} cancelled`);
    }

    return tx.challan.update({
      where: { id },
      data: { status: 'CANCELLED', cancelledAt: new Date() },
      include: { items: true, customer: true },
    });
  });
}

export async function getChallanById(id: string) {
  const challan = await prisma.challan.findUnique({
    where: { id },
    include: {
      items: true,
      customer: true,
      createdBy: { select: { name: true } },
    },
  });
  if (!challan) throw ApiError.notFound('Challan not found');
  return challan;
}

export async function listChallans(
  pagination: PaginationParams,
  status?: ChallanStatus,
  customerId?: string,
  search?: string
) {
  const where: Record<string, unknown> = {};
  if (status) where.status = status;
  if (customerId) where.customerId = customerId;
  if (search) where.challanNumber = { contains: search, mode: 'insensitive' };

  const [items, total] = await Promise.all([
    prisma.challan.findMany({
      where,
      skip: pagination.skip,
      take: pagination.limit,
      orderBy: { createdAt: 'desc' },
      include: {
        customer: { select: { name: true, businessName: true } },
        createdBy: { select: { name: true } },
        items: true,
      },
    }),
    prisma.challan.count({ where }),
  ]);

  return { items, meta: buildMeta(total, pagination.page, pagination.limit) };
}
