import { MovementType } from '@prisma/client';
import { prisma } from '../config/prisma';
import { ApiError } from '../utils/ApiError';
import { PaginationParams, buildMeta } from '../utils/pagination';

export async function listProducts(
  pagination: PaginationParams,
  search?: string,
  category?: string,
  lowStockOnly?: boolean
) {
  const where: Record<string, unknown> = {};
  if (search) {
    where.OR = [
      { name: { contains: search, mode: 'insensitive' } },
      { sku: { contains: search, mode: 'insensitive' } },
      { category: { contains: search, mode: 'insensitive' } },
    ];
  }
  if (category) where.category = category;

  let items = await prisma.product.findMany({
    where,
    skip: lowStockOnly ? undefined : pagination.skip,
    take: lowStockOnly ? undefined : pagination.limit,
    orderBy: { createdAt: 'desc' },
  });
  let total = await prisma.product.count({ where });

  if (lowStockOnly) {
    items = items.filter((p) => p.currentStock <= p.minStockAlert);
    total = items.length;
    items = items.slice(pagination.skip, pagination.skip + pagination.limit);
  }

  return { items, meta: buildMeta(total, pagination.page, pagination.limit) };
}

export async function getProductById(id: string) {
  const product = await prisma.product.findUnique({
    where: { id },
    include: {
      stockMovements: {
        orderBy: { createdAt: 'desc' },
        take: 50,
        include: { createdBy: { select: { name: true } } },
      },
    },
  });
  if (!product) throw ApiError.notFound('Product not found');
  return product;
}

interface ProductInput {
  name: string;
  sku: string;
  category: string;
  unitPrice: number;
  currentStock?: number;
  minStockAlert?: number;
  location?: string;
}

export async function createProduct(input: ProductInput) {
  const existing = await prisma.product.findUnique({ where: { sku: input.sku } });
  if (existing) throw ApiError.conflict('A product with this SKU already exists');
  return prisma.product.create({ data: input });
}

export async function updateProduct(id: string, input: Partial<ProductInput> & { isActive?: boolean }) {
  await getProductById(id);
  if (input.sku) {
    const existing = await prisma.product.findUnique({ where: { sku: input.sku } });
    if (existing && existing.id !== id) throw ApiError.conflict('A product with this SKU already exists');
  }
  return prisma.product.update({ where: { id }, data: input });
}

/**
 * Records a manual stock movement (IN or OUT) and atomically updates the
 * product's currentStock. Used for manual adjustments (e.g. restock,
 * damage write-off, stock count correction) — separate from the automatic
 * OUT movements created by confirming a Sales Challan.
 */
export async function recordStockMovement(
  productId: string,
  createdById: string,
  quantity: number,
  movementType: MovementType,
  reason: string
) {
  return prisma.$transaction(async (tx) => {
    const product = await tx.product.findUnique({ where: { id: productId } });
    if (!product) throw ApiError.notFound('Product not found');

    if (movementType === 'OUT' && product.currentStock < quantity) {
      throw ApiError.conflict(
        `Insufficient stock for ${product.name} (SKU: ${product.sku}). Available: ${product.currentStock}, requested: ${quantity}.`
      );
    }

    const newStock =
      movementType === 'IN' ? product.currentStock + quantity : product.currentStock - quantity;

    const updatedProduct = await tx.product.update({
      where: { id: productId },
      data: { currentStock: newStock },
    });

    const movement = await tx.stockMovement.create({
      data: { productId, quantityChanged: quantity, movementType, reason, createdById },
    });

    return { product: updatedProduct, movement };
  });
}

export async function listStockMovements(
  pagination: PaginationParams,
  productId?: string,
  movementType?: MovementType
) {
  const where: Record<string, unknown> = {};
  if (productId) where.productId = productId;
  if (movementType) where.movementType = movementType;

  const [items, total] = await Promise.all([
    prisma.stockMovement.findMany({
      where,
      skip: pagination.skip,
      take: pagination.limit,
      orderBy: { createdAt: 'desc' },
      include: {
        product: { select: { name: true, sku: true } },
        createdBy: { select: { name: true } },
      },
    }),
    prisma.stockMovement.count({ where }),
  ]);

  return { items, meta: buildMeta(total, pagination.page, pagination.limit) };
}
