import { CustomerStatus, CustomerType } from '@prisma/client';
import { prisma } from '../config/prisma';
import { ApiError } from '../utils/ApiError';
import { PaginationParams, buildMeta } from '../utils/pagination';

export async function listCustomers(
  pagination: PaginationParams,
  search?: string,
  status?: CustomerStatus,
  customerType?: CustomerType
) {
  const where: Record<string, unknown> = {};
  if (search) {
    where.OR = [
      { name: { contains: search, mode: 'insensitive' } },
      { mobile: { contains: search, mode: 'insensitive' } },
      { email: { contains: search, mode: 'insensitive' } },
      { businessName: { contains: search, mode: 'insensitive' } },
      { gstNumber: { contains: search, mode: 'insensitive' } },
    ];
  }
  if (status) where.status = status;
  if (customerType) where.customerType = customerType;

  const [items, total] = await Promise.all([
    prisma.customer.findMany({
      where,
      skip: pagination.skip,
      take: pagination.limit,
      orderBy: { createdAt: 'desc' },
    }),
    prisma.customer.count({ where }),
  ]);

  return { items, meta: buildMeta(total, pagination.page, pagination.limit) };
}

export async function getCustomerById(id: string) {
  const customer = await prisma.customer.findUnique({
    where: { id },
    include: {
      followUps: { orderBy: { createdAt: 'desc' }, include: { createdBy: { select: { name: true } } } },
      challans: { orderBy: { createdAt: 'desc' }, take: 20 },
    },
  });
  if (!customer) throw ApiError.notFound('Customer not found');
  return customer;
}

interface CustomerInput {
  name: string;
  mobile: string;
  email?: string;
  businessName?: string;
  gstNumber?: string;
  customerType?: CustomerType;
  address?: string;
  status?: CustomerStatus;
  followUpDate?: string;
  notes?: string;
}

export async function createCustomer(input: CustomerInput) {
  return prisma.customer.create({
    data: {
      ...input,
      followUpDate: input.followUpDate ? new Date(input.followUpDate) : undefined,
    },
  });
}

export async function updateCustomer(id: string, input: Partial<CustomerInput>) {
  await getCustomerById(id);
  return prisma.customer.update({
    where: { id },
    data: {
      ...input,
      followUpDate: input.followUpDate ? new Date(input.followUpDate) : undefined,
    },
  });
}

export async function addFollowUp(
  customerId: string,
  createdById: string,
  note: string,
  followUpDate?: string
) {
  await getCustomerById(customerId);

  const followUp = await prisma.followUp.create({
    data: {
      customerId,
      createdById,
      note,
      followUpDate: followUpDate ? new Date(followUpDate) : undefined,
    },
    include: { createdBy: { select: { name: true } } },
  });

  // Keep the customer's headline follow-up date in sync with the latest entry
  if (followUpDate) {
    await prisma.customer.update({
      where: { id: customerId },
      data: { followUpDate: new Date(followUpDate) },
    });
  }

  return followUp;
}
