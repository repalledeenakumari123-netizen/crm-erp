import { body, param } from 'express-validator';

export const createProductValidator = [
  body('name').isString().trim().notEmpty().withMessage('Product name is required'),
  body('sku').isString().trim().notEmpty().withMessage('SKU/code is required'),
  body('category').isString().trim().notEmpty().withMessage('Category is required'),
  body('unitPrice').isFloat({ min: 0 }).withMessage('Unit price must be a positive number'),
  body('currentStock').optional().isInt({ min: 0 }).withMessage('Current stock must be a non-negative integer'),
  body('minStockAlert')
    .optional()
    .isInt({ min: 0 })
    .withMessage('Minimum stock alert must be a non-negative integer'),
  body('location').optional().isString(),
];

export const updateProductValidator = [
  param('id').isUUID().withMessage('Invalid product id'),
  body('name').optional().isString().trim().notEmpty(),
  body('sku').optional().isString().trim().notEmpty(),
  body('category').optional().isString().trim().notEmpty(),
  body('unitPrice').optional().isFloat({ min: 0 }),
  body('minStockAlert').optional().isInt({ min: 0 }),
  body('location').optional().isString(),
  body('isActive').optional().isBoolean(),
];

export const stockMovementValidator = [
  param('id').isUUID().withMessage('Invalid product id'),
  body('quantity').isInt({ min: 1 }).withMessage('Quantity must be a positive integer'),
  body('movementType').isIn(['IN', 'OUT']).withMessage('Movement type must be IN or OUT'),
  body('reason').isString().trim().notEmpty().withMessage('Reason is required'),
];

export const idParamValidator = [param('id').isUUID().withMessage('Invalid id')];
