import { body, param } from 'express-validator';

export const createCustomerValidator = [
  body('name').isString().trim().notEmpty().withMessage('Customer name is required'),
  body('mobile').isString().trim().notEmpty().withMessage('Mobile number is required'),
  body('email').optional({ nullable: true }).isEmail().withMessage('Invalid email'),
  body('businessName').optional().isString(),
  body('gstNumber').optional().isString(),
  body('customerType')
    .optional()
    .isIn(['RETAIL', 'WHOLESALE', 'DISTRIBUTOR'])
    .withMessage('Invalid customer type'),
  body('address').optional().isString(),
  body('status').optional().isIn(['LEAD', 'ACTIVE', 'INACTIVE']).withMessage('Invalid status'),
  body('followUpDate').optional({ nullable: true }).isISO8601().withMessage('Invalid follow-up date'),
  body('notes').optional().isString(),
];

export const updateCustomerValidator = [
  param('id').isUUID().withMessage('Invalid customer id'),
  body('name').optional().isString().trim().notEmpty(),
  body('mobile').optional().isString().trim().notEmpty(),
  body('email').optional({ nullable: true }).isEmail(),
  body('businessName').optional().isString(),
  body('gstNumber').optional().isString(),
  body('customerType').optional().isIn(['RETAIL', 'WHOLESALE', 'DISTRIBUTOR']),
  body('address').optional().isString(),
  body('status').optional().isIn(['LEAD', 'ACTIVE', 'INACTIVE']),
  body('followUpDate').optional({ nullable: true }).isISO8601(),
  body('notes').optional().isString(),
];

export const addFollowUpValidator = [
  param('id').isUUID().withMessage('Invalid customer id'),
  body('note').isString().trim().notEmpty().withMessage('Note is required'),
  body('followUpDate').optional({ nullable: true }).isISO8601().withMessage('Invalid follow-up date'),
];

export const idParamValidator = [param('id').isUUID().withMessage('Invalid id')];
