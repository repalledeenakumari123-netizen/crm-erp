import { body, param } from 'express-validator';

export const createChallanValidator = [
  body('customerId').isUUID().withMessage('Valid customer is required'),
  body('items').isArray({ min: 1 }).withMessage('At least one product line item is required'),
  body('items.*.productId').isUUID().withMessage('Invalid product id in items'),
  body('items.*.quantity').isInt({ min: 1 }).withMessage('Quantity must be a positive integer'),
];

export const updateChallanValidator = [
  param('id').isUUID().withMessage('Invalid challan id'),
  body('customerId').optional().isUUID(),
  body('items').optional().isArray({ min: 1 }).withMessage('At least one product line item is required'),
  body('items.*.productId').optional().isUUID(),
  body('items.*.quantity').optional().isInt({ min: 1 }),
];

export const idParamValidator = [param('id').isUUID().withMessage('Invalid id')];
