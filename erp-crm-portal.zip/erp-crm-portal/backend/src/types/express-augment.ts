import { JwtPayload } from '../utils/jwt';

// Augmenting 'express-serve-static-core' (the module that actually declares
// Request/Response) rather than `declare global { namespace Express }` is
// more robust against duplicate @types/express copies in node_modules.
//
// This lives in a regular .ts file (not .d.ts) and is explicitly imported
// as a side effect from server.ts (import './types/express-augment').
// Pure ambient .d.ts files can be silently skipped by ts-node's lazy,
// import-graph-based compilation (unlike `tsc`, which reads the whole
// `include` glob upfront) — making this a real, importable module
// guarantees the augmentation is always loaded, under both `tsc` and
// `ts-node`/nodemon.
declare module 'express-serve-static-core' {
  interface Request {
    user?: JwtPayload;
  }
}

export {};
