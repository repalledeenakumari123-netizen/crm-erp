import { Router } from 'express';
import { Role } from '@prisma/client';
import * as authController from '../controllers/auth.controller';
import { loginValidator, changePasswordValidator, createUserValidator } from '../validators/auth.validator';
import { validate } from '../middleware/validate';
import { authenticate } from '../middleware/auth';
import { authorize } from '../middleware/rbac';

const router = Router();

router.post('/login', loginValidator, validate, authController.login);
router.post('/refresh', authController.refreshToken);
router.post('/logout', authenticate, authController.logout);
router.get('/me', authenticate, authController.me);
router.post(
  '/change-password',
  authenticate,
  changePasswordValidator,
  validate,
  authController.changePassword
);

// User management — Admin only (creating Sales/Warehouse/Accounts logins)
router.post('/users', authenticate, authorize(Role.ADMIN), createUserValidator, validate, authController.createUser);
router.get('/users', authenticate, authorize(Role.ADMIN), authController.listUsers);

export default router;
