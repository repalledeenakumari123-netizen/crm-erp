import { Router } from 'express';
import { Role } from '@prisma/client';
import * as challanController from '../controllers/challan.controller';
import {
  createChallanValidator,
  updateChallanValidator,
  idParamValidator,
} from '../validators/challan.validator';
import { validate } from '../middleware/validate';
import { authenticate } from '../middleware/auth';
import { authorize } from '../middleware/rbac';

const router = Router();

router.use(authenticate);

// Admin & Sales create/manage challans (spec: "a sales user should be able
// to..."). Warehouse/Accounts can view challans (Warehouse to fulfill
// orders, Accounts for billing) but not create or modify them.
const canView = authorize(Role.ADMIN, Role.SALES, Role.WAREHOUSE, Role.ACCOUNTS);
const canManage = authorize(Role.ADMIN, Role.SALES);

router.get('/', canView, challanController.listChallans);
router.get('/:id', canView, idParamValidator, validate, challanController.getChallan);
router.post('/', canManage, createChallanValidator, validate, challanController.createChallan);
router.put('/:id', canManage, updateChallanValidator, validate, challanController.updateChallan);
router.put('/:id/confirm', canManage, idParamValidator, validate, challanController.confirmChallan);
router.put('/:id/cancel', canManage, idParamValidator, validate, challanController.cancelChallan);

export default router;
