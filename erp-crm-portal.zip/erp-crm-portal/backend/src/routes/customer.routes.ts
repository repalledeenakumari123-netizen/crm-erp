import { Router } from 'express';
import { Role } from '@prisma/client';
import * as customerController from '../controllers/customer.controller';
import {
  createCustomerValidator,
  updateCustomerValidator,
  addFollowUpValidator,
  idParamValidator,
} from '../validators/customer.validator';
import { validate } from '../middleware/validate';
import { authenticate } from '../middleware/auth';
import { authorize } from '../middleware/rbac';

const router = Router();

router.use(authenticate);

// Admin, Sales, and Accounts can view customers. Warehouse has no need for
// customer data (spec: Warehouse manages products/inventory only).
const canView = authorize(Role.ADMIN, Role.SALES, Role.ACCOUNTS);
// Only Admin and Sales create/edit customer records and follow-ups.
const canManage = authorize(Role.ADMIN, Role.SALES);

router.get('/', canView, customerController.listCustomers);
router.get('/:id', canView, idParamValidator, validate, customerController.getCustomer);
router.post('/', canManage, createCustomerValidator, validate, customerController.createCustomer);
router.put('/:id', canManage, updateCustomerValidator, validate, customerController.updateCustomer);
router.post(
  '/:id/follow-ups',
  canManage,
  addFollowUpValidator,
  validate,
  customerController.addFollowUp
);

export default router;
