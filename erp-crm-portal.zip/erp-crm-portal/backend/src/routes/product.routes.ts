import { Router } from 'express';
import { Role } from '@prisma/client';
import * as productController from '../controllers/product.controller';
import {
  createProductValidator,
  updateProductValidator,
  stockMovementValidator,
  idParamValidator,
} from '../validators/product.validator';
import { validate } from '../middleware/validate';
import { authenticate } from '../middleware/auth';
import { authorize } from '../middleware/rbac';

const router = Router();

router.use(authenticate);

// Everyone (Admin/Sales/Warehouse/Accounts) can view products & stock — Sales
// needs it to build challans, Accounts for valuation/reporting.
const canManage = authorize(Role.ADMIN, Role.WAREHOUSE);

router.get('/', productController.listProducts);
router.get('/movements', productController.listStockMovements);
router.get('/:id', idParamValidator, validate, productController.getProduct);
router.post('/', canManage, createProductValidator, validate, productController.createProduct);
router.put('/:id', canManage, updateProductValidator, validate, productController.updateProduct);
router.post(
  '/:id/movements',
  canManage,
  stockMovementValidator,
  validate,
  productController.recordStockMovement
);

export default router;
