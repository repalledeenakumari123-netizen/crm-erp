// Runs automatically before `npm run dev` (see package.json "predev").
// Kills whatever process is currently listening on the configured PORT,
// so a stale/zombie node process from a previous run never blocks the
// next `npm run dev` with EADDRINUSE.
require('dotenv').config();

const kill = require('kill-port');

const port = process.env.PORT || 5000;

kill(port, 'tcp')
  .then(() => {
    console.log(`[free-port] Port ${port} is now free.`);
  })
  .catch(() => {
    console.log(`[free-port] Port ${port} was already free.`);
  });
