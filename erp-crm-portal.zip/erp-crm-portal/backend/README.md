# ERP + CRM Portal — Backend

Node.js + Express + TypeScript + Prisma + PostgreSQL REST API.

## Quick Start

```bash
npm install
cp .env.example .env   # then edit DATABASE_URL, JWT_SECRET, JWT_REFRESH_SECRET
npx prisma generate
npx prisma migrate dev --name init
npm run seed
npm run dev
```

API runs at `http://localhost:5000/api/v1`. See the root [README](../README.md) for full documentation, role permissions, and deployment instructions.

## Scripts

| Script | Description |
|---|---|
| `npm run dev` | Start dev server with hot reload (auto-frees the configured port first) |
| `npm run build` | Compile TypeScript to `dist/` |
| `npm start` | Run compiled build from `dist/` |
| `npm run prisma:generate` | Generate Prisma Client |
| `npm run prisma:migrate` | Create & apply a new migration |
| `npm run prisma:deploy` | Apply migrations in production (no prompts) |
| `npm run prisma:studio` | Open Prisma Studio |
| `npm run seed` | Seed sample data (4 users, 3 customers, 3 products, 2 challans) |

## Folder Structure

```
src/
├── config/       # env, prisma client, logger
├── controllers/  # request handlers
├── services/     # business logic / Prisma queries (challan.service.ts holds the core stock-safety logic)
├── routes/       # Express routers (role-gated per module)
├── middleware/   # auth, rbac, validation, error handling
├── validators/   # express-validator rule sets
├── utils/        # ApiError, asyncHandler, pagination, jwt
├── types/        # Express Request augmentation
├── app.ts
└── server.ts
prisma/
├── schema.prisma
└── seed.ts
```
