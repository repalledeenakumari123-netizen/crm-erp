import {
  PrismaClient,
  Role,
  CustomerType,
  CustomerStatus,
  MovementType,
} from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  console.log('Seeding database...');

  const password = await bcrypt.hash('Password@123', 10);

  const [admin, sales, warehouse, accounts] = await Promise.all([
    prisma.user.upsert({
      where: { email: 'admin@erpcrm.com' },
      update: {},
      create: { name: 'Ravi Admin', email: 'admin@erpcrm.com', password, role: Role.ADMIN },
    }),
    prisma.user.upsert({
      where: { email: 'sales@erpcrm.com' },
      update: {},
      create: { name: 'Anita Sales', email: 'sales@erpcrm.com', password, role: Role.SALES },
    }),
    prisma.user.upsert({
      where: { email: 'warehouse@erpcrm.com' },
      update: {},
      create: { name: 'Suresh Warehouse', email: 'warehouse@erpcrm.com', password, role: Role.WAREHOUSE },
    }),
    prisma.user.upsert({
      where: { email: 'accounts@erpcrm.com' },
      update: {},
      create: { name: 'Meena Accounts', email: 'accounts@erpcrm.com', password, role: Role.ACCOUNTS },
    }),
  ]);

  const customers = await Promise.all([
    prisma.customer.create({
      data: {
        name: 'Rajesh Traders',
        mobile: '9876543210',
        email: 'rajesh@traders.com',
        businessName: 'Rajesh Traders Pvt Ltd',
        gstNumber: '27ABCDE1234F1Z5',
        customerType: CustomerType.WHOLESALE,
        address: 'Shop 12, APMC Market, Mumbai',
        status: CustomerStatus.ACTIVE,
      },
    }),
    prisma.customer.create({
      data: {
        name: 'Priya Distributors',
        mobile: '9123456780',
        email: 'priya@distributors.com',
        businessName: 'Priya Distribution Co.',
        customerType: CustomerType.DISTRIBUTOR,
        address: 'Plot 45, Industrial Area, Pune',
        status: CustomerStatus.ACTIVE,
      },
    }),
    prisma.customer.create({
      data: {
        name: 'Sunil Kirana Store',
        mobile: '9988776655',
        customerType: CustomerType.RETAIL,
        address: 'Main Bazaar, Nashik',
        status: CustomerStatus.LEAD,
        followUpDate: new Date(new Date().setDate(new Date().getDate() + 5)),
      },
    }),
  ]);

  await prisma.followUp.create({
    data: {
      customerId: customers[2].id,
      createdById: sales.id,
      note: 'Called to introduce new product catalog. Interested, follow up next week.',
      followUpDate: new Date(new Date().setDate(new Date().getDate() + 5)),
    },
  });

  const products = await Promise.all([
    prisma.product.create({
      data: {
        name: 'Steel Pipe 1 inch',
        sku: 'STL-PIPE-1IN',
        category: 'Steel',
        unitPrice: 250,
        currentStock: 500,
        minStockAlert: 50,
        location: 'Warehouse A - Rack 3',
      },
    }),
    prisma.product.create({
      data: {
        name: 'Cement Bag 50kg',
        sku: 'CEM-BAG-50',
        category: 'Cement',
        unitPrice: 380,
        currentStock: 20,
        minStockAlert: 30,
        location: 'Warehouse A - Rack 1',
      },
    }),
    prisma.product.create({
      data: {
        name: 'PVC Fitting Elbow 2 inch',
        sku: 'PVC-ELB-2IN',
        category: 'PVC',
        unitPrice: 45,
        currentStock: 1000,
        minStockAlert: 100,
        location: 'Warehouse B - Rack 5',
      },
    }),
  ]);

  await prisma.stockMovement.create({
    data: {
      productId: products[0].id,
      quantityChanged: 500,
      movementType: MovementType.IN,
      reason: 'Initial stock entry',
      createdById: warehouse.id,
    },
  });

  const challan = await prisma.challan.create({
    data: {
      challanNumber: 'CH-00001',
      customerId: customers[0].id,
      createdById: sales.id,
      totalQuantity: 60,
      status: 'CONFIRMED',
      confirmedAt: new Date(),
      items: {
        create: [
          {
            productId: products[0].id,
            productNameSnapshot: products[0].name,
            productSkuSnapshot: products[0].sku,
            unitPriceSnapshot: products[0].unitPrice,
            quantity: 50,
            lineTotal: Number(products[0].unitPrice) * 50,
          },
          {
            productId: products[2].id,
            productNameSnapshot: products[2].name,
            productSkuSnapshot: products[2].sku,
            unitPriceSnapshot: products[2].unitPrice,
            quantity: 10,
            lineTotal: Number(products[2].unitPrice) * 10,
          },
        ],
      },
    },
  });

  // Reflect the confirmed challan's stock deduction and log it, matching
  // what the real confirm-challan flow would have done.
  await prisma.product.update({
    where: { id: products[0].id },
    data: { currentStock: { decrement: 50 } },
  });
  await prisma.product.update({
    where: { id: products[2].id },
    data: { currentStock: { decrement: 10 } },
  });
  await prisma.stockMovement.createMany({
    data: [
      {
        productId: products[0].id,
        quantityChanged: 50,
        movementType: MovementType.OUT,
        reason: `Sales Challan ${challan.challanNumber}`,
        createdById: sales.id,
      },
      {
        productId: products[2].id,
        quantityChanged: 10,
        movementType: MovementType.OUT,
        reason: `Sales Challan ${challan.challanNumber}`,
        createdById: sales.id,
      },
    ],
  });

  await prisma.challan.create({
    data: {
      challanNumber: 'CH-00002',
      customerId: customers[1].id,
      createdById: sales.id,
      totalQuantity: 20,
      status: 'DRAFT',
      items: {
        create: [
          {
            productId: products[1].id,
            productNameSnapshot: products[1].name,
            productSkuSnapshot: products[1].sku,
            unitPriceSnapshot: products[1].unitPrice,
            quantity: 20,
            lineTotal: Number(products[1].unitPrice) * 20,
          },
        ],
      },
    },
  });

  console.log('Seeding complete.');
  console.log('---------------------------------------------');
  console.log('Login credentials (password for all: Password@123)');
  console.log(`Admin:     ${admin.email}`);
  console.log(`Sales:     ${sales.email}`);
  console.log(`Warehouse: ${warehouse.email}`);
  console.log(`Accounts:  ${accounts.email}`);
  console.log('---------------------------------------------');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
