# ERP + CRM Portal — Frontend

React + TypeScript + Vite + Tailwind CSS admin-style SPA.

## Quick Start

```bash
npm install
cp .env.example .env   # adjust VITE_API_BASE_URL if needed
npm run dev
```

Runs at `http://localhost:5173`. Requires the backend API running — see `../backend/README.md`.

## Scripts

| Script | Description |
|---|---|
| `npm run dev` | Start Vite dev server |
| `npm run build` | Type-check and build for production into `dist/` |
| `npm run preview` | Preview the production build locally |

## Folder Structure

```
src/
├── components/   # reusable UI + feature modals (customer/product/challan forms)
├── layouts/      # AuthLayout, DashboardLayout
├── pages/        # Login, Dashboard, Customers, Products, StockMovements, Challans
├── context/      # AuthContext
├── hooks/        # useDebounce
├── services/     # axios client + per-module API functions
├── types/        # shared TypeScript types
├── App.tsx       # route definitions with role-gated ProtectedRoute
└── main.tsx
```

## Tech Stack

React 18 · TypeScript · Vite · React Router DOM · Axios · Tailwind CSS · React Hook Form (including `useFieldArray` for the multi-product challan form) · React Hot Toast · Heroicons
