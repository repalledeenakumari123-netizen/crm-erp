import { useEffect, useState } from 'react';
import { useForm, useFieldArray } from 'react-hook-form';
import toast from 'react-hot-toast';
import { PlusIcon, TrashIcon } from '@heroicons/react/24/outline';
import Modal from './common/Modal';
import Select from './common/Select';
import Input from './common/Input';
import Button from './common/Button';
import { getErrorMessage } from '../services/api';
import * as challanService from '../services/challan.service';
import * as customerService from '../services/customer.service';
import * as productService from '../services/product.service';
import { Customer, Product } from '../types';

interface ChallanFormValues {
  customerId: string;
  items: { productId: string; quantity: number }[];
}

export default function ChallanFormModal({
  isOpen,
  onClose,
  onSaved,
}: {
  isOpen: boolean;
  onClose: () => void;
  onSaved: () => void;
}) {
  const [isSubmitting, setIsSubmitting] = useState<'draft' | 'confirm' | null>(null);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [products, setProducts] = useState<Product[]>([]);

  const {
    register,
    handleSubmit,
    reset,
    control,
    watch,
    formState: { errors },
  } = useForm<ChallanFormValues>({
    defaultValues: { items: [{ productId: '', quantity: 1 }] },
  });

  const { fields, append, remove } = useFieldArray({ control, name: 'items' });
  const watchedItems = watch('items');

  useEffect(() => {
    if (isOpen) {
      reset({ items: [{ productId: '', quantity: 1 }] });
      customerService.listCustomers(1, 200).then((r) => setCustomers(r.items));
      productService.listProducts(1, 200).then((r) => setProducts(r.items));
    }
  }, [isOpen, reset]);

  function productFor(productId: string) {
    return products.find((p) => p.id === productId);
  }

  const estimatedTotal = (watchedItems || []).reduce((sum, item) => {
    const product = productFor(item.productId);
    if (!product || !item.quantity) return sum;
    return sum + Number(product.unitPrice) * Number(item.quantity);
  }, 0);

  async function submit(values: ChallanFormValues, status: 'DRAFT' | 'CONFIRMED') {
    setIsSubmitting(status === 'DRAFT' ? 'draft' : 'confirm');
    try {
      await challanService.createChallan(
        values.customerId,
        values.items.map((i) => ({ productId: i.productId, quantity: Number(i.quantity) })),
        status
      );
      toast.success(status === 'DRAFT' ? 'Challan saved as draft' : 'Challan confirmed and stock updated');
      onSaved();
      onClose();
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setIsSubmitting(null);
    }
  }

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Create Sales Challan" widthClass="max-w-3xl">
      <form className="space-y-5">
        <Select
          label="Customer"
          placeholder="Select customer"
          options={customers.map((c) => ({
            label: `${c.name}${c.businessName ? ` (${c.businessName})` : ''}`,
            value: c.id,
          }))}
          error={errors.customerId?.message}
          {...register('customerId', { required: 'Customer is required' })}
        />

        <div>
          <div className="mb-2 flex items-center justify-between">
            <label className="text-sm font-medium text-gray-700">Line Items</label>
            <Button type="button" variant="ghost" onClick={() => append({ productId: '', quantity: 1 })}>
              <PlusIcon className="h-4 w-4" /> Add product
            </Button>
          </div>

          <div className="space-y-3">
            {fields.map((field, index) => {
              const selectedProduct = productFor(watchedItems?.[index]?.productId);
              return (
                <div key={field.id} className="flex items-end gap-3 rounded-lg border border-gray-200 p-3">
                  <div className="flex-1">
                    <Select
                      label="Product"
                      placeholder="Select product"
                      options={products.map((p) => ({
                        label: `${p.name} (${p.sku}) — Stock: ${p.currentStock}`,
                        value: p.id,
                      }))}
                      {...register(`items.${index}.productId`, { required: 'Required' })}
                    />
                  </div>
                  <div className="w-28">
                    <Input
                      label="Quantity"
                      type="number"
                      {...register(`items.${index}.quantity`, { required: true, min: 1, valueAsNumber: true })}
                    />
                  </div>
                  <div className="w-28 pb-2 text-sm text-gray-500">
                    {selectedProduct
                      ? `₹${(Number(selectedProduct.unitPrice) * (watchedItems?.[index]?.quantity || 0)).toLocaleString('en-IN')}`
                      : '—'}
                  </div>
                  <button
                    type="button"
                    onClick={() => fields.length > 1 && remove(index)}
                    className="mb-1 rounded-lg p-2 text-red-500 hover:bg-red-50 disabled:opacity-30"
                    disabled={fields.length <= 1}
                  >
                    <TrashIcon className="h-4 w-4" />
                  </button>
                </div>
              );
            })}
          </div>
        </div>

        <div className="flex items-center justify-between rounded-lg bg-gray-50 px-4 py-3 text-sm">
          <span className="text-gray-500">Estimated Total</span>
          <span className="text-lg font-semibold text-gray-900">₹{estimatedTotal.toLocaleString('en-IN')}</span>
        </div>

        <div className="flex justify-end gap-3 pt-2">
          <Button type="button" variant="secondary" onClick={onClose}>
            Cancel
          </Button>
          <Button
            type="button"
            variant="secondary"
            isLoading={isSubmitting === 'draft'}
            onClick={handleSubmit((v) => submit(v, 'DRAFT'))}
          >
            Save as Draft
          </Button>
          <Button
            type="button"
            isLoading={isSubmitting === 'confirm'}
            onClick={handleSubmit((v) => submit(v, 'CONFIRMED'))}
          >
            Confirm &amp; Deduct Stock
          </Button>
        </div>
      </form>
    </Modal>
  );
}
