import { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import toast from 'react-hot-toast';
import Modal from './common/Modal';
import Input from './common/Input';
import Select from './common/Select';
import Textarea from './common/Textarea';
import Button from './common/Button';
import { getErrorMessage } from '../services/api';
import * as customerService from '../services/customer.service';
import { Customer } from '../types';

interface CustomerFormValues {
  name: string;
  mobile: string;
  email?: string;
  businessName?: string;
  gstNumber?: string;
  customerType: string;
  address?: string;
  status: string;
  followUpDate?: string;
  notes?: string;
}

interface CustomerFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSaved: () => void;
  customer?: Customer | null;
}

export default function CustomerFormModal({ isOpen, onClose, onSaved, customer }: CustomerFormModalProps) {
  const isEdit = Boolean(customer);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<CustomerFormValues>();

  useEffect(() => {
    if (isOpen) {
      reset(
        customer
          ? {
              name: customer.name,
              mobile: customer.mobile,
              email: customer.email || '',
              businessName: customer.businessName || '',
              gstNumber: customer.gstNumber || '',
              customerType: customer.customerType,
              address: customer.address || '',
              status: customer.status,
              followUpDate: customer.followUpDate ? customer.followUpDate.slice(0, 10) : '',
              notes: customer.notes || '',
            }
          : { customerType: 'RETAIL', status: 'LEAD' }
      );
    }
  }, [isOpen, customer, reset]);

  async function onSubmit(values: CustomerFormValues) {
    setIsSubmitting(true);
    try {
      if (isEdit && customer) {
        await customerService.updateCustomer(customer.id, values);
        toast.success('Customer updated');
      } else {
        await customerService.createCustomer(values);
        toast.success('Customer created');
      }
      onSaved();
      onClose();
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={isEdit ? 'Edit Customer' : 'Add Customer'} widthClass="max-w-2xl">
      <form onSubmit={handleSubmit(onSubmit)} className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <Input
          label="Customer Name"
          error={errors.name?.message}
          {...register('name', { required: 'Name is required' })}
        />
        <Input
          label="Mobile Number"
          error={errors.mobile?.message}
          {...register('mobile', { required: 'Mobile number is required' })}
        />
        <Input label="Email" type="email" {...register('email')} />
        <Input label="Business Name" {...register('businessName')} />
        <Input label="GST Number (optional)" {...register('gstNumber')} />
        <Select
          label="Customer Type"
          options={[
            { label: 'Retail', value: 'RETAIL' },
            { label: 'Wholesale', value: 'WHOLESALE' },
            { label: 'Distributor', value: 'DISTRIBUTOR' },
          ]}
          {...register('customerType')}
        />
        <Select
          label="Status"
          options={[
            { label: 'Lead', value: 'LEAD' },
            { label: 'Active', value: 'ACTIVE' },
            { label: 'Inactive', value: 'INACTIVE' },
          ]}
          {...register('status')}
        />
        <Input label="Follow-up Date" type="date" {...register('followUpDate')} />
        <div className="col-span-full">
          <Input label="Address" {...register('address')} />
        </div>
        <div className="col-span-full">
          <Textarea label="Notes" {...register('notes')} />
        </div>

        <div className="col-span-full mt-2 flex justify-end gap-3">
          <Button type="button" variant="secondary" onClick={onClose}>
            Cancel
          </Button>
          <Button type="submit" isLoading={isSubmitting}>
            {isEdit ? 'Save Changes' : 'Create Customer'}
          </Button>
        </div>
      </form>
    </Modal>
  );
}
