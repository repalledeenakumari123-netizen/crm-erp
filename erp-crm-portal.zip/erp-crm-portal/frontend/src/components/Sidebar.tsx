import { NavLink } from 'react-router-dom';
import {
  HomeIcon,
  UserGroupIcon,
  CubeIcon,
  ClipboardDocumentListIcon,
  ArchiveBoxIcon,
} from '@heroicons/react/24/outline';
import { useAuth } from '../context/AuthContext';
import { Role } from '../types';

const navItems: { to: string; label: string; icon: typeof HomeIcon; roles: Role[] }[] = [
  { to: '/dashboard', label: 'Dashboard', icon: HomeIcon, roles: ['ADMIN', 'SALES', 'WAREHOUSE', 'ACCOUNTS'] },
  { to: '/customers', label: 'Customers', icon: UserGroupIcon, roles: ['ADMIN', 'SALES', 'ACCOUNTS'] },
  { to: '/products', label: 'Products', icon: CubeIcon, roles: ['ADMIN', 'SALES', 'WAREHOUSE', 'ACCOUNTS'] },
  {
    to: '/stock-movements',
    label: 'Stock Movements',
    icon: ArchiveBoxIcon,
    roles: ['ADMIN', 'WAREHOUSE', 'ACCOUNTS'],
  },
  {
    to: '/challans',
    label: 'Sales Challans',
    icon: ClipboardDocumentListIcon,
    roles: ['ADMIN', 'SALES', 'WAREHOUSE', 'ACCOUNTS'],
  },
];

export default function Sidebar() {
  const { user } = useAuth();

  return (
    <aside className="hidden w-60 shrink-0 flex-col border-r border-gray-200 bg-white md:flex">
      <div className="flex h-16 items-center gap-2 border-b border-gray-200 px-5">
        <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary-600 text-sm font-bold text-white">
          E
        </div>
        <span className="text-lg font-semibold text-gray-900">ERP + CRM</span>
      </div>
      <nav className="flex-1 space-y-1 px-3 py-4">
        {navItems
          .filter((item) => !user || item.roles.includes(user.role))
          .map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              className={({ isActive }) =>
                `flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors ${
                  isActive
                    ? 'bg-primary-50 text-primary-700'
                    : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                }`
              }
            >
              <item.icon className="h-5 w-5" />
              {item.label}
            </NavLink>
          ))}
      </nav>
    </aside>
  );
}
