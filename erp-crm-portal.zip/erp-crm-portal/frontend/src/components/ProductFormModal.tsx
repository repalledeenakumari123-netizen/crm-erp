import { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import toast from 'react-hot-toast';
import Modal from './common/Modal';
import Input from './common/Input';
import Button from './common/Button';
import { getErrorMessage } from '../services/api';
import * as productService from '../services/product.service';
import { Product } from '../types';

interface ProductFormValues {
  name: string;
  sku: string;
  category: string;
  unitPrice: number;
  currentStock?: number;
  minStockAlert?: number;
  location?: string;
}

interface ProductFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSaved: () => void;
  product?: Product | null;
}

export default function ProductFormModal({ isOpen, onClose, onSaved, product }: ProductFormModalProps) {
  const isEdit = Boolean(product);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<ProductFormValues>();

  useEffect(() => {
    if (isOpen) {
      reset(
        product
          ? {
              name: product.name,
              sku: product.sku,
              category: product.category,
              unitPrice: Number(product.unitPrice),
              minStockAlert: product.minStockAlert,
              location: product.location || '',
            }
          : { currentStock: 0, minStockAlert: 0 }
      );
    }
  }, [isOpen, product, reset]);

  async function onSubmit(values: ProductFormValues) {
    setIsSubmitting(true);
    try {
      if (isEdit && product) {
        await productService.updateProduct(product.id, {
          name: values.name,
          sku: values.sku,
          category: values.category,
          unitPrice: Number(values.unitPrice),
          minStockAlert: Number(values.minStockAlert),
          location: values.location,
        });
        toast.success('Product updated');
      } else {
        await productService.createProduct({
          name: values.name,
          sku: values.sku,
          category: values.category,
          unitPrice: Number(values.unitPrice),
          currentStock: Number(values.currentStock) || 0,
          minStockAlert: Number(values.minStockAlert) || 0,
          location: values.location,
        });
        toast.success('Product created');
      }
      onSaved();
      onClose();
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={isEdit ? 'Edit Product' : 'Add Product'} widthClass="max-w-2xl">
      <form onSubmit={handleSubmit(onSubmit)} className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <Input
          label="Product Name"
          error={errors.name?.message}
          {...register('name', { required: 'Product name is required' })}
        />
        <Input
          label="SKU / Code"
          error={errors.sku?.message}
          {...register('sku', { required: 'SKU is required' })}
        />
        <Input
          label="Category"
          error={errors.category?.message}
          {...register('category', { required: 'Category is required' })}
        />
        <Input
          label="Unit Price"
          type="number"
          step="0.01"
          error={errors.unitPrice?.message}
          {...register('unitPrice', { required: 'Unit price is required', min: 0 })}
        />
        {!isEdit && (
          <Input label="Opening Stock" type="number" {...register('currentStock', { min: 0 })} />
        )}
        <Input label="Minimum Stock Alert Qty" type="number" {...register('minStockAlert', { min: 0 })} />
        <div className="col-span-full">
          <Input label="Location / Warehouse" {...register('location')} />
        </div>

        <div className="col-span-full mt-2 flex justify-end gap-3">
          <Button type="button" variant="secondary" onClick={onClose}>
            Cancel
          </Button>
          <Button type="submit" isLoading={isSubmitting}>
            {isEdit ? 'Save Changes' : 'Create Product'}
          </Button>
        </div>
      </form>
    </Modal>
  );
}
