import { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import toast from 'react-hot-toast';
import Modal from './common/Modal';
import Textarea from './common/Textarea';
import Input from './common/Input';
import Button from './common/Button';
import { Badge, LoadingSpinner } from './common/Feedback';
import { getErrorMessage } from '../services/api';
import * as customerService from '../services/customer.service';
import { Customer } from '../types';
import { useAuth } from '../context/AuthContext';

interface FollowUpFormValues {
  note: string;
  followUpDate?: string;
}

export default function CustomerDetailModal({
  customerId,
  onClose,
}: {
  customerId: string;
  onClose: () => void;
}) {
  const { user } = useAuth();
  const canAddFollowUp = user?.role === 'ADMIN' || user?.role === 'SALES';
  const [customer, setCustomer] = useState<Customer | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<FollowUpFormValues>();

  async function load() {
    setIsLoading(true);
    try {
      const data = await customerService.getCustomer(customerId);
      setCustomer(data);
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setIsLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [customerId]);

  async function onSubmit(values: FollowUpFormValues) {
    setIsSubmitting(true);
    try {
      await customerService.addFollowUp(customerId, values.note, values.followUpDate);
      toast.success('Follow-up note added');
      reset();
      load();
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <Modal isOpen onClose={onClose} title="Customer Details" widthClass="max-w-2xl">
      {isLoading || !customer ? (
        <LoadingSpinner />
      ) : (
        <div className="space-y-5">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-lg font-semibold text-gray-900">{customer.name}</p>
              <p className="text-sm text-gray-500">{customer.businessName || 'No business name'}</p>
            </div>
            <div className="flex gap-2">
              <Badge status={customer.customerType} />
              <Badge status={customer.status} />
            </div>
          </div>

          <dl className="grid grid-cols-2 gap-x-4 gap-y-3 text-sm">
            <div>
              <dt className="text-gray-500">Mobile</dt>
              <dd className="font-medium text-gray-900">{customer.mobile}</dd>
            </div>
            <div>
              <dt className="text-gray-500">Email</dt>
              <dd className="font-medium text-gray-900">{customer.email || '—'}</dd>
            </div>
            <div>
              <dt className="text-gray-500">GST Number</dt>
              <dd className="font-medium text-gray-900">{customer.gstNumber || '—'}</dd>
            </div>
            <div>
              <dt className="text-gray-500">Next Follow-up</dt>
              <dd className="font-medium text-gray-900">
                {customer.followUpDate ? new Date(customer.followUpDate).toLocaleDateString() : '—'}
              </dd>
            </div>
            <div className="col-span-2">
              <dt className="text-gray-500">Address</dt>
              <dd className="font-medium text-gray-900">{customer.address || '—'}</dd>
            </div>
            {customer.notes && (
              <div className="col-span-2">
                <dt className="text-gray-500">Notes</dt>
                <dd className="font-medium text-gray-900">{customer.notes}</dd>
              </div>
            )}
          </dl>

          <div>
            <h4 className="mb-2 text-sm font-semibold text-gray-700">Follow-up History</h4>
            <div className="max-h-48 space-y-2 overflow-y-auto rounded-lg border border-gray-100 bg-gray-50 p-3">
              {(!customer.followUps || customer.followUps.length === 0) && (
                <p className="text-sm text-gray-400">No follow-up notes yet.</p>
              )}
              {customer.followUps?.map((f) => (
                <div key={f.id} className="rounded-lg bg-white p-2.5 text-sm shadow-sm">
                  <p className="text-gray-800">{f.note}</p>
                  <p className="mt-1 text-xs text-gray-400">
                    {f.createdBy?.name || 'Unknown'} · {new Date(f.createdAt).toLocaleString()}
                    {f.followUpDate && ` · Next: ${new Date(f.followUpDate).toLocaleDateString()}`}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {canAddFollowUp && (
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-3 border-t border-gray-100 pt-4">
              <Textarea
                label="Add Follow-up Note"
                error={errors.note?.message}
                {...register('note', { required: 'Note is required' })}
              />
              <Input label="Next Follow-up Date (optional)" type="date" {...register('followUpDate')} />
              <div className="flex justify-end">
                <Button type="submit" isLoading={isSubmitting}>
                  Add Note
                </Button>
              </div>
            </form>
          )}
        </div>
      )}
    </Modal>
  );
}
