import { useState } from 'react';
import { useForm } from 'react-hook-form';
import toast from 'react-hot-toast';
import Modal from './common/Modal';
import Input from './common/Input';
import Select from './common/Select';
import Button from './common/Button';
import { getErrorMessage } from '../services/api';
import * as productService from '../services/product.service';
import { Product } from '../types';

interface MovementFormValues {
  quantity: number;
  movementType: 'IN' | 'OUT';
  reason: string;
}

export default function StockMovementModal({
  product,
  onClose,
  onSaved,
}: {
  product: Product;
  onClose: () => void;
  onSaved: () => void;
}) {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<MovementFormValues>({ defaultValues: { movementType: 'IN' } });

  async function onSubmit(values: MovementFormValues) {
    setIsSubmitting(true);
    try {
      await productService.recordStockMovement(
        product.id,
        Number(values.quantity),
        values.movementType,
        values.reason
      );
      toast.success('Stock movement recorded');
      onSaved();
      onClose();
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <Modal isOpen onClose={onClose} title={`Record Stock Movement — ${product.name}`}>
      <p className="mb-4 text-sm text-gray-500">
        Current stock: <span className="font-medium text-gray-800">{product.currentStock}</span> (SKU:{' '}
        {product.sku})
      </p>
      <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
        <Select
          label="Movement Type"
          options={[
            { label: 'IN (add stock)', value: 'IN' },
            { label: 'OUT (remove stock)', value: 'OUT' },
          ]}
          {...register('movementType', { required: true })}
        />
        <Input
          label="Quantity"
          type="number"
          error={errors.quantity?.message}
          {...register('quantity', { required: 'Quantity is required', min: 1 })}
        />
        <Input
          label="Reason"
          placeholder="e.g. Restock from supplier, damage write-off, stock count correction"
          error={errors.reason?.message}
          {...register('reason', { required: 'Reason is required' })}
        />
        <div className="flex justify-end gap-3 pt-2">
          <Button type="button" variant="secondary" onClick={onClose}>
            Cancel
          </Button>
          <Button type="submit" isLoading={isSubmitting}>
            Record Movement
          </Button>
        </div>
      </form>
    </Modal>
  );
}
