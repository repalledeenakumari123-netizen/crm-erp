export function LoadingSpinner({ fullScreen = false }: { fullScreen?: boolean }) {
  const spinner = (
    <svg className="h-8 w-8 animate-spin text-primary-600" viewBox="0 0 24 24" fill="none">
      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z" />
    </svg>
  );

  if (fullScreen) {
    return <div className="flex h-full min-h-[60vh] w-full items-center justify-center">{spinner}</div>;
  }
  return spinner;
}

const badgeColors: Record<string, string> = {
  LEAD: 'bg-yellow-100 text-yellow-700',
  ACTIVE: 'bg-green-100 text-green-700',
  INACTIVE: 'bg-gray-100 text-gray-700',
  RETAIL: 'bg-blue-100 text-blue-700',
  WHOLESALE: 'bg-purple-100 text-purple-700',
  DISTRIBUTOR: 'bg-indigo-100 text-indigo-700',
  DRAFT: 'bg-gray-100 text-gray-700',
  CONFIRMED: 'bg-green-100 text-green-700',
  CANCELLED: 'bg-red-100 text-red-700',
  IN: 'bg-green-100 text-green-700',
  OUT: 'bg-orange-100 text-orange-700',
  ADMIN: 'bg-purple-100 text-purple-700',
  SALES: 'bg-blue-100 text-blue-700',
  WAREHOUSE: 'bg-orange-100 text-orange-700',
  ACCOUNTS: 'bg-teal-100 text-teal-700',
};

export function Badge({ status }: { status: string }) {
  return (
    <span
      className={`inline-flex rounded-full px-2.5 py-0.5 text-xs font-medium ${
        badgeColors[status] || 'bg-gray-100 text-gray-700'
      }`}
    >
      {status}
    </span>
  );
}
