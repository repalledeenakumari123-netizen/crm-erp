import { useEffect, useState } from 'react';
import toast from 'react-hot-toast';
import Modal from './common/Modal';
import Button from './common/Button';
import { Badge, LoadingSpinner } from './common/Feedback';
import { getErrorMessage } from '../services/api';
import * as challanService from '../services/challan.service';
import { Challan } from '../types';
import { useAuth } from '../context/AuthContext';

export default function ChallanDetailModal({
  challanId,
  onClose,
  onChanged,
}: {
  challanId: string;
  onClose: () => void;
  onChanged: () => void;
}) {
  const { user } = useAuth();
  const canManage = user?.role === 'ADMIN' || user?.role === 'SALES';
  const [challan, setChallan] = useState<Challan | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState<'confirm' | 'cancel' | null>(null);

  async function load() {
    setIsLoading(true);
    try {
      const data = await challanService.getChallan(challanId);
      setChallan(data);
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setIsLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [challanId]);

  async function handleConfirm() {
    if (!confirm('Confirm this challan? This will deduct stock for all line items.')) return;
    setActionLoading('confirm');
    try {
      await challanService.confirmChallan(challanId);
      toast.success('Challan confirmed and stock updated');
      load();
      onChanged();
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setActionLoading(null);
    }
  }

  async function handleCancel() {
    const msg =
      challan?.status === 'CONFIRMED'
        ? 'Cancel this confirmed challan? Stock will be restored for all line items.'
        : 'Cancel this draft challan?';
    if (!confirm(msg)) return;
    setActionLoading('cancel');
    try {
      await challanService.cancelChallan(challanId);
      toast.success('Challan cancelled');
      load();
      onChanged();
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setActionLoading(null);
    }
  }

  return (
    <Modal isOpen onClose={onClose} title={challan ? `Challan ${challan.challanNumber}` : 'Challan'} widthClass="max-w-2xl">
      {isLoading || !challan ? (
        <LoadingSpinner />
      ) : (
        <div className="space-y-5">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-lg font-semibold text-gray-900">
                {challan.customer?.name}
                {challan.customer?.businessName && (
                  <span className="text-sm font-normal text-gray-500"> ({challan.customer.businessName})</span>
                )}
              </p>
              <p className="text-sm text-gray-500">
                Created by {challan.createdBy?.name || '—'} on {new Date(challan.createdAt).toLocaleString()}
              </p>
            </div>
            <Badge status={challan.status} />
          </div>

          <div className="overflow-hidden rounded-lg border border-gray-200">
            <table className="min-w-full divide-y divide-gray-200 text-sm">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-3 py-2 text-left text-xs font-semibold uppercase text-gray-500">Product</th>
                  <th className="px-3 py-2 text-left text-xs font-semibold uppercase text-gray-500">SKU</th>
                  <th className="px-3 py-2 text-right text-xs font-semibold uppercase text-gray-500">Qty</th>
                  <th className="px-3 py-2 text-right text-xs font-semibold uppercase text-gray-500">Unit Price</th>
                  <th className="px-3 py-2 text-right text-xs font-semibold uppercase text-gray-500">Line Total</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {challan.items.map((item) => (
                  <tr key={item.id}>
                    <td className="px-3 py-2">{item.productNameSnapshot}</td>
                    <td className="px-3 py-2 text-gray-500">{item.productSkuSnapshot}</td>
                    <td className="px-3 py-2 text-right">{item.quantity}</td>
                    <td className="px-3 py-2 text-right">₹{Number(item.unitPriceSnapshot).toLocaleString('en-IN')}</td>
                    <td className="px-3 py-2 text-right font-medium">
                      ₹{Number(item.lineTotal).toLocaleString('en-IN')}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="flex items-center justify-between rounded-lg bg-gray-50 px-4 py-3 text-sm">
            <span className="text-gray-500">Total Quantity: {challan.totalQuantity}</span>
            <span className="text-lg font-semibold text-gray-900">
              ₹
              {challan.items
                .reduce((sum, i) => sum + Number(i.lineTotal), 0)
                .toLocaleString('en-IN')}
            </span>
          </div>

          {canManage && challan.status !== 'CANCELLED' && (
            <div className="flex justify-end gap-3 border-t border-gray-100 pt-4">
              {challan.status === 'DRAFT' && (
                <Button isLoading={actionLoading === 'confirm'} onClick={handleConfirm}>
                  Confirm &amp; Deduct Stock
                </Button>
              )}
              <Button variant="danger" isLoading={actionLoading === 'cancel'} onClick={handleCancel}>
                Cancel Challan
              </Button>
            </div>
          )}
        </div>
      )}
    </Modal>
  );
}
