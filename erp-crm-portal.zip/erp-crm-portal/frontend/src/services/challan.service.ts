import { api } from './api';
import { Challan, PaginatedResponse } from '../types';

export interface ChallanItemPayload {
  productId: string;
  quantity: number;
}

export async function listChallans(page = 1, limit = 10, status?: string, search?: string) {
  const { data } = await api.get<PaginatedResponse<Challan>>('/challans', {
    params: { page, limit, status, search: search || undefined },
  });
  return data;
}

export async function getChallan(id: string) {
  const { data } = await api.get(`/challans/${id}`);
  return data.data as Challan;
}

export async function createChallan(
  customerId: string,
  items: ChallanItemPayload[],
  status: 'DRAFT' | 'CONFIRMED' = 'DRAFT'
) {
  const { data } = await api.post('/challans', { customerId, items, status });
  return data.data as Challan;
}

export async function updateChallan(
  id: string,
  payload: { customerId?: string; items?: ChallanItemPayload[] }
) {
  const { data } = await api.put(`/challans/${id}`, payload);
  return data.data as Challan;
}

export async function confirmChallan(id: string) {
  const { data } = await api.put(`/challans/${id}/confirm`);
  return data.data as Challan;
}

export async function cancelChallan(id: string) {
  const { data } = await api.put(`/challans/${id}/cancel`);
  return data.data as Challan;
}
