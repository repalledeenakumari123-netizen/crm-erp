import { api } from './api';
import { Customer, PaginatedResponse } from '../types';

export interface CustomerPayload {
  name: string;
  mobile: string;
  email?: string;
  businessName?: string;
  gstNumber?: string;
  customerType?: string;
  address?: string;
  status?: string;
  followUpDate?: string;
  notes?: string;
}

export async function listCustomers(
  page = 1,
  limit = 10,
  search = '',
  status?: string,
  customerType?: string
) {
  const { data } = await api.get<PaginatedResponse<Customer>>('/customers', {
    params: { page, limit, search: search || undefined, status, customerType },
  });
  return data;
}

export async function getCustomer(id: string) {
  const { data } = await api.get(`/customers/${id}`);
  return data.data as Customer;
}

export async function createCustomer(payload: CustomerPayload) {
  const { data } = await api.post('/customers', payload);
  return data.data as Customer;
}

export async function updateCustomer(id: string, payload: Partial<CustomerPayload>) {
  const { data } = await api.put(`/customers/${id}`, payload);
  return data.data as Customer;
}

export async function addFollowUp(id: string, note: string, followUpDate?: string) {
  const { data } = await api.post(`/customers/${id}/follow-ups`, { note, followUpDate });
  return data.data;
}
