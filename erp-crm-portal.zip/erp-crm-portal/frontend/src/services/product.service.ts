import { api } from './api';
import { Product, StockMovement, PaginatedResponse } from '../types';

export interface ProductPayload {
  name: string;
  sku: string;
  category: string;
  unitPrice: number;
  currentStock?: number;
  minStockAlert?: number;
  location?: string;
  isActive?: boolean;
}

export async function listProducts(
  page = 1,
  limit = 10,
  search = '',
  category?: string,
  lowStockOnly = false
) {
  const { data } = await api.get<PaginatedResponse<Product>>('/products', {
    params: { page, limit, search: search || undefined, category, lowStockOnly: lowStockOnly || undefined },
  });
  return data;
}

export async function getProduct(id: string) {
  const { data } = await api.get(`/products/${id}`);
  return data.data as Product;
}

export async function createProduct(payload: ProductPayload) {
  const { data } = await api.post('/products', payload);
  return data.data as Product;
}

export async function updateProduct(id: string, payload: Partial<ProductPayload>) {
  const { data } = await api.put(`/products/${id}`, payload);
  return data.data as Product;
}

export async function recordStockMovement(
  id: string,
  quantity: number,
  movementType: 'IN' | 'OUT',
  reason: string
) {
  const { data } = await api.post(`/products/${id}/movements`, { quantity, movementType, reason });
  return data.data;
}

export async function listStockMovements(page = 1, limit = 10, productId?: string, movementType?: string) {
  const { data } = await api.get<PaginatedResponse<StockMovement>>('/products/movements', {
    params: { page, limit, productId, movementType },
  });
  return data;
}
