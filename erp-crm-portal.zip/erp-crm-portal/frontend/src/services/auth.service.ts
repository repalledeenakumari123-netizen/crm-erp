import { api } from './api';
import { AuthUser } from '../types';

export async function login(email: string, password: string) {
  const { data } = await api.post('/auth/login', { email, password });
  return data.data as { accessToken: string; refreshToken: string; user: AuthUser };
}

export async function logout() {
  await api.post('/auth/logout');
}

export async function getMe() {
  const { data } = await api.get('/auth/me');
  return data.data;
}

export async function changePassword(currentPassword: string, newPassword: string) {
  const { data } = await api.post('/auth/change-password', { currentPassword, newPassword });
  return data;
}

export async function createUser(payload: { name: string; email: string; password: string; role: string }) {
  const { data } = await api.post('/auth/users', payload);
  return data.data;
}

export async function listUsers() {
  const { data } = await api.get('/auth/users');
  return data.data;
}
