import { Routes, Route, Navigate } from 'react-router-dom';
import AuthLayout from './layouts/AuthLayout';
import DashboardLayout from './layouts/DashboardLayout';
import ProtectedRoute from './components/ProtectedRoute';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import Customers from './pages/Customers';
import Products from './pages/Products';
import StockMovements from './pages/StockMovements';
import Challans from './pages/Challans';
import NotFound from './pages/NotFound';

export default function App() {
  return (
    <Routes>
      <Route element={<AuthLayout />}>
        <Route path="/login" element={<Login />} />
      </Route>

      <Route
        element={
          <ProtectedRoute>
            <DashboardLayout />
          </ProtectedRoute>
        }
      >
        <Route path="/dashboard" element={<Dashboard />} />
        <Route
          path="/customers"
          element={
            <ProtectedRoute roles={['ADMIN', 'SALES', 'ACCOUNTS']}>
              <Customers />
            </ProtectedRoute>
          }
        />
        <Route path="/products" element={<Products />} />
        <Route
          path="/stock-movements"
          element={
            <ProtectedRoute roles={['ADMIN', 'WAREHOUSE', 'ACCOUNTS']}>
              <StockMovements />
            </ProtectedRoute>
          }
        />
        <Route path="/challans" element={<Challans />} />
      </Route>

      <Route path="/" element={<Navigate to="/dashboard" replace />} />
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
}
