import { useEffect, useState, useCallback } from 'react';
import toast from 'react-hot-toast';
import { PlusIcon, PencilIcon, EyeIcon } from '@heroicons/react/24/outline';
import * as customerService from '../services/customer.service';
import { getErrorMessage } from '../services/api';
import { Customer, PaginationMeta } from '../types';
import { Table, TableHead, TableBody, EmptyState } from '../components/common/Table';
import Pagination from '../components/common/Pagination';
import SearchBar from '../components/common/SearchBar';
import Select from '../components/common/Select';
import Button from '../components/common/Button';
import { Badge, LoadingSpinner } from '../components/common/Feedback';
import { useDebounce } from '../hooks/useDebounce';
import CustomerFormModal from '../components/CustomerFormModal';
import CustomerDetailModal from '../components/CustomerDetailModal';
import { useAuth } from '../context/AuthContext';

export default function Customers() {
  const { user } = useAuth();
  const canManage = user?.role === 'ADMIN' || user?.role === 'SALES';

  const [customers, setCustomers] = useState<Customer[]>([]);
  const [meta, setMeta] = useState<PaginationMeta>({ total: 0, page: 1, limit: 10, totalPages: 1 });
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const debouncedSearch = useDebounce(search);
  const [isLoading, setIsLoading] = useState(true);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingCustomer, setEditingCustomer] = useState<Customer | null>(null);
  const [viewingCustomerId, setViewingCustomerId] = useState<string | null>(null);

  const loadCustomers = useCallback(async () => {
    setIsLoading(true);
    try {
      const result = await customerService.listCustomers(page, 10, debouncedSearch, statusFilter || undefined);
      setCustomers(result.items);
      setMeta(result.meta);
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setIsLoading(false);
    }
  }, [page, debouncedSearch, statusFilter]);

  useEffect(() => {
    loadCustomers();
  }, [loadCustomers]);

  useEffect(() => {
    setPage(1);
  }, [debouncedSearch, statusFilter]);

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h1 className="text-2xl font-semibold text-gray-900">Customers</h1>
        <div className="flex items-center gap-3">
          <SearchBar value={search} onChange={setSearch} placeholder="Search name, mobile, GST..." />
          <Select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            placeholder="All statuses"
            options={[
              { label: 'Lead', value: 'LEAD' },
              { label: 'Active', value: 'ACTIVE' },
              { label: 'Inactive', value: 'INACTIVE' },
            ]}
          />
          {canManage && (
            <Button
              onClick={() => {
                setEditingCustomer(null);
                setIsFormOpen(true);
              }}
            >
              <PlusIcon className="h-4 w-4" /> Add Customer
            </Button>
          )}
        </div>
      </div>

      {isLoading ? (
        <LoadingSpinner fullScreen />
      ) : (
        <Table>
          <TableHead columns={['Name', 'Mobile', 'Business', 'Type', 'Status', 'Follow-up', 'Actions']} />
          <TableBody>
            {customers.length === 0 && <EmptyState colSpan={7} message="No customers found" />}
            {customers.map((c) => (
              <tr key={c.id} className="hover:bg-gray-50">
                <td className="px-4 py-3 font-medium text-gray-700">{c.name}</td>
                <td className="px-4 py-3 text-gray-600">{c.mobile}</td>
                <td className="px-4 py-3 text-gray-600">{c.businessName || '—'}</td>
                <td className="px-4 py-3">
                  <Badge status={c.customerType} />
                </td>
                <td className="px-4 py-3">
                  <Badge status={c.status} />
                </td>
                <td className="px-4 py-3 text-gray-600">
                  {c.followUpDate ? new Date(c.followUpDate).toLocaleDateString() : '—'}
                </td>
                <td className="px-4 py-3">
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setViewingCustomerId(c.id)}
                      className="rounded-lg p-1.5 text-gray-500 hover:bg-gray-100"
                      title="View details"
                    >
                      <EyeIcon className="h-4 w-4" />
                    </button>
                    {canManage && (
                      <button
                        onClick={() => {
                          setEditingCustomer(c);
                          setIsFormOpen(true);
                        }}
                        className="rounded-lg p-1.5 text-gray-500 hover:bg-gray-100"
                        title="Edit"
                      >
                        <PencilIcon className="h-4 w-4" />
                      </button>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </TableBody>
        </Table>
      )}

      {!isLoading && meta.total > 0 && <Pagination meta={meta} onPageChange={setPage} />}

      <CustomerFormModal
        isOpen={isFormOpen}
        onClose={() => setIsFormOpen(false)}
        onSaved={loadCustomers}
        customer={editingCustomer}
      />

      {viewingCustomerId && (
        <CustomerDetailModal customerId={viewingCustomerId} onClose={() => setViewingCustomerId(null)} />
      )}
    </div>
  );
}
