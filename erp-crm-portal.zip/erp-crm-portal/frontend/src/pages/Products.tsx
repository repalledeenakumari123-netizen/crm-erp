import { useEffect, useState, useCallback } from 'react';
import toast from 'react-hot-toast';
import { PlusIcon, PencilIcon, ArchiveBoxArrowDownIcon } from '@heroicons/react/24/outline';
import * as productService from '../services/product.service';
import { getErrorMessage } from '../services/api';
import { Product, PaginationMeta } from '../types';
import { Table, TableHead, TableBody, EmptyState } from '../components/common/Table';
import Pagination from '../components/common/Pagination';
import SearchBar from '../components/common/SearchBar';
import Button from '../components/common/Button';
import { LoadingSpinner } from '../components/common/Feedback';
import { useDebounce } from '../hooks/useDebounce';
import ProductFormModal from '../components/ProductFormModal';
import StockMovementModal from '../components/StockMovementModal';
import { useAuth } from '../context/AuthContext';

export default function Products() {
  const { user } = useAuth();
  const canManage = user?.role === 'ADMIN' || user?.role === 'WAREHOUSE';

  const [products, setProducts] = useState<Product[]>([]);
  const [meta, setMeta] = useState<PaginationMeta>({ total: 0, page: 1, limit: 10, totalPages: 1 });
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');
  const [lowStockOnly, setLowStockOnly] = useState(false);
  const debouncedSearch = useDebounce(search);
  const [isLoading, setIsLoading] = useState(true);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [movementProduct, setMovementProduct] = useState<Product | null>(null);

  const loadProducts = useCallback(async () => {
    setIsLoading(true);
    try {
      const result = await productService.listProducts(page, 10, debouncedSearch, undefined, lowStockOnly);
      setProducts(result.items);
      setMeta(result.meta);
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setIsLoading(false);
    }
  }, [page, debouncedSearch, lowStockOnly]);

  useEffect(() => {
    loadProducts();
  }, [loadProducts]);

  useEffect(() => {
    setPage(1);
  }, [debouncedSearch, lowStockOnly]);

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h1 className="text-2xl font-semibold text-gray-900">Products &amp; Inventory</h1>
        <div className="flex items-center gap-3">
          <SearchBar value={search} onChange={setSearch} placeholder="Search name, SKU, category..." />
          <label className="flex items-center gap-2 text-sm text-gray-600">
            <input
              type="checkbox"
              checked={lowStockOnly}
              onChange={(e) => setLowStockOnly(e.target.checked)}
              className="rounded border-gray-300 text-primary-600 focus:ring-primary-500"
            />
            Low stock only
          </label>
          {canManage && (
            <Button
              onClick={() => {
                setEditingProduct(null);
                setIsFormOpen(true);
              }}
            >
              <PlusIcon className="h-4 w-4" /> Add Product
            </Button>
          )}
        </div>
      </div>

      {isLoading ? (
        <LoadingSpinner fullScreen />
      ) : (
        <Table>
          <TableHead columns={['Name', 'SKU', 'Category', 'Unit Price', 'Stock', 'Location', 'Actions']} />
          <TableBody>
            {products.length === 0 && <EmptyState colSpan={7} message="No products found" />}
            {products.map((p) => {
              const isLow = p.currentStock <= p.minStockAlert;
              return (
                <tr key={p.id} className="hover:bg-gray-50">
                  <td className="px-4 py-3 font-medium text-gray-700">{p.name}</td>
                  <td className="px-4 py-3 text-gray-600">{p.sku}</td>
                  <td className="px-4 py-3 text-gray-600">{p.category}</td>
                  <td className="px-4 py-3 text-gray-600">₹{Number(p.unitPrice).toLocaleString('en-IN')}</td>
                  <td className="px-4 py-3">
                    <span className={isLow ? 'font-semibold text-red-600' : 'text-gray-700'}>
                      {p.currentStock}
                    </span>
                    {isLow && <span className="ml-1 text-xs text-red-500">(low)</span>}
                  </td>
                  <td className="px-4 py-3 text-gray-600">{p.location || '—'}</td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      {canManage && (
                        <>
                          <button
                            onClick={() => {
                              setEditingProduct(p);
                              setIsFormOpen(true);
                            }}
                            className="rounded-lg p-1.5 text-gray-500 hover:bg-gray-100"
                            title="Edit"
                          >
                            <PencilIcon className="h-4 w-4" />
                          </button>
                          <button
                            onClick={() => setMovementProduct(p)}
                            className="rounded-lg p-1.5 text-gray-500 hover:bg-gray-100"
                            title="Record stock movement"
                          >
                            <ArchiveBoxArrowDownIcon className="h-4 w-4" />
                          </button>
                        </>
                      )}
                    </div>
                  </td>
                </tr>
              );
            })}
          </TableBody>
        </Table>
      )}

      {!isLoading && meta.total > 0 && <Pagination meta={meta} onPageChange={setPage} />}

      <ProductFormModal
        isOpen={isFormOpen}
        onClose={() => setIsFormOpen(false)}
        onSaved={loadProducts}
        product={editingProduct}
      />

      {movementProduct && (
        <StockMovementModal
          product={movementProduct}
          onClose={() => setMovementProduct(null)}
          onSaved={loadProducts}
        />
      )}
    </div>
  );
}
