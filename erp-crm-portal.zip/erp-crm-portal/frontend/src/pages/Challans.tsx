import { useEffect, useState, useCallback } from 'react';
import toast from 'react-hot-toast';
import { PlusIcon, EyeIcon } from '@heroicons/react/24/outline';
import * as challanService from '../services/challan.service';
import { getErrorMessage } from '../services/api';
import { Challan, PaginationMeta } from '../types';
import { Table, TableHead, TableBody, EmptyState } from '../components/common/Table';
import Pagination from '../components/common/Pagination';
import SearchBar from '../components/common/SearchBar';
import Select from '../components/common/Select';
import Button from '../components/common/Button';
import { Badge, LoadingSpinner } from '../components/common/Feedback';
import { useDebounce } from '../hooks/useDebounce';
import ChallanFormModal from '../components/ChallanFormModal';
import ChallanDetailModal from '../components/ChallanDetailModal';
import { useAuth } from '../context/AuthContext';

export default function Challans() {
  const { user } = useAuth();
  const canCreate = user?.role === 'ADMIN' || user?.role === 'SALES';

  const [challans, setChallans] = useState<Challan[]>([]);
  const [meta, setMeta] = useState<PaginationMeta>({ total: 0, page: 1, limit: 10, totalPages: 1 });
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const debouncedSearch = useDebounce(search);
  const [isLoading, setIsLoading] = useState(true);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [viewingChallanId, setViewingChallanId] = useState<string | null>(null);

  const loadChallans = useCallback(async () => {
    setIsLoading(true);
    try {
      const result = await challanService.listChallans(page, 10, statusFilter || undefined, debouncedSearch);
      setChallans(result.items);
      setMeta(result.meta);
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setIsLoading(false);
    }
  }, [page, statusFilter, debouncedSearch]);

  useEffect(() => {
    loadChallans();
  }, [loadChallans]);

  useEffect(() => {
    setPage(1);
  }, [statusFilter, debouncedSearch]);

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h1 className="text-2xl font-semibold text-gray-900">Sales Challans</h1>
        <div className="flex items-center gap-3">
          <SearchBar value={search} onChange={setSearch} placeholder="Search challan number..." />
          <Select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            placeholder="All statuses"
            options={[
              { label: 'Draft', value: 'DRAFT' },
              { label: 'Confirmed', value: 'CONFIRMED' },
              { label: 'Cancelled', value: 'CANCELLED' },
            ]}
          />
          {canCreate && (
            <Button onClick={() => setIsFormOpen(true)}>
              <PlusIcon className="h-4 w-4" /> New Challan
            </Button>
          )}
        </div>
      </div>

      {isLoading ? (
        <LoadingSpinner fullScreen />
      ) : (
        <Table>
          <TableHead columns={['Challan #', 'Customer', 'Total Qty', 'Status', 'Created By', 'Date', 'Actions']} />
          <TableBody>
            {challans.length === 0 && <EmptyState colSpan={7} message="No sales challans found" />}
            {challans.map((c) => (
              <tr key={c.id} className="hover:bg-gray-50">
                <td className="px-4 py-3 font-medium text-gray-700">{c.challanNumber}</td>
                <td className="px-4 py-3 text-gray-600">
                  {c.customer?.name}
                  {c.customer?.businessName && <span className="text-gray-400"> ({c.customer.businessName})</span>}
                </td>
                <td className="px-4 py-3 text-gray-600">{c.totalQuantity}</td>
                <td className="px-4 py-3">
                  <Badge status={c.status} />
                </td>
                <td className="px-4 py-3 text-gray-600">{c.createdBy?.name || '—'}</td>
                <td className="px-4 py-3 text-gray-600">{new Date(c.createdAt).toLocaleDateString()}</td>
                <td className="px-4 py-3">
                  <button
                    onClick={() => setViewingChallanId(c.id)}
                    className="rounded-lg p-1.5 text-gray-500 hover:bg-gray-100"
                    title="View details"
                  >
                    <EyeIcon className="h-4 w-4" />
                  </button>
                </td>
              </tr>
            ))}
          </TableBody>
        </Table>
      )}

      {!isLoading && meta.total > 0 && <Pagination meta={meta} onPageChange={setPage} />}

      <ChallanFormModal isOpen={isFormOpen} onClose={() => setIsFormOpen(false)} onSaved={loadChallans} />

      {viewingChallanId && (
        <ChallanDetailModal
          challanId={viewingChallanId}
          onClose={() => setViewingChallanId(null)}
          onChanged={loadChallans}
        />
      )}
    </div>
  );
}
