import { useEffect, useState, useCallback } from 'react';
import toast from 'react-hot-toast';
import * as productService from '../services/product.service';
import { getErrorMessage } from '../services/api';
import { StockMovement, PaginationMeta } from '../types';
import { Table, TableHead, TableBody, EmptyState } from '../components/common/Table';
import Pagination from '../components/common/Pagination';
import Select from '../components/common/Select';
import { Badge, LoadingSpinner } from '../components/common/Feedback';

export default function StockMovements() {
  const [movements, setMovements] = useState<StockMovement[]>([]);
  const [meta, setMeta] = useState<PaginationMeta>({ total: 0, page: 1, limit: 10, totalPages: 1 });
  const [page, setPage] = useState(1);
  const [typeFilter, setTypeFilter] = useState('');
  const [isLoading, setIsLoading] = useState(true);

  const loadMovements = useCallback(async () => {
    setIsLoading(true);
    try {
      const result = await productService.listStockMovements(page, 15, undefined, typeFilter || undefined);
      setMovements(result.items);
      setMeta(result.meta);
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setIsLoading(false);
    }
  }, [page, typeFilter]);

  useEffect(() => {
    loadMovements();
  }, [loadMovements]);

  useEffect(() => {
    setPage(1);
  }, [typeFilter]);

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h1 className="text-2xl font-semibold text-gray-900">Stock Movement Log</h1>
        <Select
          value={typeFilter}
          onChange={(e) => setTypeFilter(e.target.value)}
          placeholder="All movements"
          options={[
            { label: 'IN', value: 'IN' },
            { label: 'OUT', value: 'OUT' },
          ]}
        />
      </div>

      {isLoading ? (
        <LoadingSpinner fullScreen />
      ) : (
        <Table>
          <TableHead columns={['Product', 'SKU', 'Type', 'Quantity', 'Reason', 'By', 'Date']} />
          <TableBody>
            {movements.length === 0 && <EmptyState colSpan={7} message="No stock movements found" />}
            {movements.map((m) => (
              <tr key={m.id} className="hover:bg-gray-50">
                <td className="px-4 py-3 font-medium text-gray-700">{m.product?.name || '—'}</td>
                <td className="px-4 py-3 text-gray-600">{m.product?.sku || '—'}</td>
                <td className="px-4 py-3">
                  <Badge status={m.movementType} />
                </td>
                <td className="px-4 py-3 text-gray-700">{m.quantityChanged}</td>
                <td className="px-4 py-3 max-w-xs truncate text-gray-600" title={m.reason}>
                  {m.reason}
                </td>
                <td className="px-4 py-3 text-gray-600">{m.createdBy?.name || '—'}</td>
                <td className="px-4 py-3 text-gray-600">{new Date(m.createdAt).toLocaleString()}</td>
              </tr>
            ))}
          </TableBody>
        </Table>
      )}

      {!isLoading && meta.total > 0 && <Pagination meta={meta} onPageChange={setPage} />}
    </div>
  );
}
