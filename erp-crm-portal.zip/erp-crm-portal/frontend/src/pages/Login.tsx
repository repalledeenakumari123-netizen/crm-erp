import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import { useAuth } from '../context/AuthContext';
import { getErrorMessage } from '../services/api';
import Input from '../components/common/Input';
import Button from '../components/common/Button';

interface LoginForm {
  email: string;
  password: string;
}

export default function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<LoginForm>();

  async function onSubmit(values: LoginForm) {
    setIsSubmitting(true);
    try {
      await login(values.email, values.password);
      toast.success('Welcome back!');
      navigate('/dashboard');
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <div>
      <h2 className="mb-1 text-xl font-semibold text-gray-900">Sign in to your account</h2>
      <p className="mb-6 text-sm text-gray-500">Enter your credentials to access the portal</p>

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
        <Input
          label="Email"
          type="email"
          placeholder="you@company.com"
          error={errors.email?.message}
          {...register('email', { required: 'Email is required' })}
        />
        <Input
          label="Password"
          type="password"
          placeholder="••••••••"
          error={errors.password?.message}
          {...register('password', { required: 'Password is required' })}
        />
        <Button type="submit" isLoading={isSubmitting} className="w-full">
          Sign In
        </Button>
      </form>

      <div className="mt-6 rounded-lg bg-gray-50 p-3 text-xs text-gray-500">
        <p className="font-medium text-gray-700">Demo credentials (after seeding):</p>
        <p>Admin: admin@erpcrm.com / Password@123</p>
        <p>Sales: sales@erpcrm.com / Password@123</p>
        <p>Warehouse: warehouse@erpcrm.com / Password@123</p>
        <p>Accounts: accounts@erpcrm.com / Password@123</p>
      </div>
    </div>
  );
}
