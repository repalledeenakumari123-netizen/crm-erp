import { useEffect, useState } from 'react';
import toast from 'react-hot-toast';
import {
  UserGroupIcon,
  CubeIcon,
  ExclamationTriangleIcon,
  ClipboardDocumentListIcon,
  DocumentIcon,
} from '@heroicons/react/24/outline';
import * as customerService from '../services/customer.service';
import * as productService from '../services/product.service';
import * as challanService from '../services/challan.service';
import { getErrorMessage } from '../services/api';
import { LoadingSpinner } from '../components/common/Feedback';
import { useAuth } from '../context/AuthContext';

interface Counts {
  customers?: number;
  products?: number;
  lowStock?: number;
  draftChallans?: number;
  confirmedChallans?: number;
}

export default function Dashboard() {
  const { user } = useAuth();
  const [counts, setCounts] = useState<Counts>({});
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const requests: Promise<void>[] = [];

        if (user?.role !== 'WAREHOUSE') {
          requests.push(
            customerService.listCustomers(1, 1).then((r) => setCounts((c) => ({ ...c, customers: r.meta.total })))
          );
        }

        requests.push(
          productService.listProducts(1, 1).then((r) => setCounts((c) => ({ ...c, products: r.meta.total })))
        );
        requests.push(
          productService
            .listProducts(1, 1, '', undefined, true)
            .then((r) => setCounts((c) => ({ ...c, lowStock: r.meta.total })))
        );
        requests.push(
          challanService
            .listChallans(1, 1, 'DRAFT')
            .then((r) => setCounts((c) => ({ ...c, draftChallans: r.meta.total })))
        );
        requests.push(
          challanService
            .listChallans(1, 1, 'CONFIRMED')
            .then((r) => setCounts((c) => ({ ...c, confirmedChallans: r.meta.total })))
        );

        await Promise.all(requests);
      } catch (err) {
        toast.error(getErrorMessage(err));
      } finally {
        setIsLoading(false);
      }
    })();
  }, [user?.role]);

  if (isLoading) return <LoadingSpinner fullScreen />;

  const cards = [
    user?.role !== 'WAREHOUSE' && {
      title: 'Total Customers',
      value: counts.customers ?? 0,
      icon: UserGroupIcon,
      accent: 'bg-blue-50 text-blue-600',
    },
    { title: 'Total Products', value: counts.products ?? 0, icon: CubeIcon, accent: 'bg-primary-50 text-primary-600' },
    {
      title: 'Low Stock Alerts',
      value: counts.lowStock ?? 0,
      icon: ExclamationTriangleIcon,
      accent: 'bg-orange-50 text-orange-600',
    },
    {
      title: 'Draft Challans',
      value: counts.draftChallans ?? 0,
      icon: DocumentIcon,
      accent: 'bg-gray-100 text-gray-600',
    },
    {
      title: 'Confirmed Challans',
      value: counts.confirmedChallans ?? 0,
      icon: ClipboardDocumentListIcon,
      accent: 'bg-green-50 text-green-600',
    },
  ].filter(Boolean) as { title: string; value: number; icon: typeof CubeIcon; accent: string }[];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold text-gray-900">Welcome, {user?.name}</h1>
        <p className="mt-1 text-sm text-gray-500">Here's a quick overview of your operations.</p>
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5">
        {cards.map((card) => (
          <div
            key={card.title}
            className="flex items-center justify-between rounded-xl border border-gray-200 bg-white p-5 shadow-sm"
          >
            <div>
              <p className="text-sm text-gray-500">{card.title}</p>
              <p className="mt-1 text-2xl font-semibold text-gray-900">{card.value}</p>
            </div>
            <div className={`rounded-lg p-3 ${card.accent}`}>
              <card.icon className="h-6 w-6" />
            </div>
          </div>
        ))}
      </div>

      {(counts.lowStock ?? 0) > 0 && (user?.role === 'ADMIN' || user?.role === 'WAREHOUSE') && (
        <div className="rounded-xl border border-orange-200 bg-orange-50 p-4 text-sm text-orange-800">
          <span className="font-medium">{counts.lowStock}</span> product(s) are at or below their minimum stock
          alert threshold. Check the Products page to restock.
        </div>
      )}
    </div>
  );
}
